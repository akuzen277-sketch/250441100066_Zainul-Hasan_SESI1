<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class layanan extends Model
{
    use HasFactory;
    protected $table = 'layanan';

    protected $fillable = [
        'id',
        'kode_layanan',
        'nama_layanan',
        'jenis',
        'tarif_per_satuan'
    ] ;
}
