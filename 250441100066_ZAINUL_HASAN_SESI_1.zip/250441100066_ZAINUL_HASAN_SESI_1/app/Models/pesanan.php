<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class pesanan extends Model
{
    use HasFactory;

    protected $table = 'pesanan';

    protected $fillalble = [
        'id',
        'nama_layanan',
        'tanggal_masuk',
        'jumlah',
        'total_biaya',
        'status'
    ];
}
