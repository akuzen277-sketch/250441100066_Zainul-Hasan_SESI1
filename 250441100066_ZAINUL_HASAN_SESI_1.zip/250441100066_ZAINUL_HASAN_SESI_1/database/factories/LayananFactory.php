<?php

namespace Database\Factories;

use App\Models\Layanan;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Layanan>
 */
class LayananFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'id'=> fake()->unique()->numerify('###########'),
            'kode_layanan'=>fake()->name(),
            'nama_layana'=>fake()->name(),
            'jenis'=>fake()->enum(),
            'tarif_per_satuan'=>fake()->integer(),
        ];
    }
}
