<?php

namespace Database\Factories;

use App\Models\Pesanan;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Pesanan>
 */
class PesananFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'id'=>fake()->unique()->numerify('#########'),
            'nama_layanan'=>fake()->name(),
            'tanggal_masuk'=>fake()->date(),
            'jumlah'=>fake()->integer(),
            'total_biaya'=>fake()->decimal(),
            'status'=>fake()->name()
        ];
    }
}
