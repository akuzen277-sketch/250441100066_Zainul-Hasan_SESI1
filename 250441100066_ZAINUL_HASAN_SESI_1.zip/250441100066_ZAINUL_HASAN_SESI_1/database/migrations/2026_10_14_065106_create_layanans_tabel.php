<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('layanans_tabel', function (Blueprint $table) {
            $table->BIGINT()->id();
            $table->string()->kode_layanan(200);
            $table->string()->nama_layanan(200);
            $table->ENUM()->jenis();
            $table->INt()->tarif_per_satuan();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('layanans_tabel');
    }
};
