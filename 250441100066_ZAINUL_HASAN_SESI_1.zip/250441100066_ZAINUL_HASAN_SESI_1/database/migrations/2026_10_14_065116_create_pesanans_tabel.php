<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pesanans_tabel', function (Blueprint $table) {
            $table->BIGINT()->id();
            $table->BIGINT()->layanan_id();
            $table->string()->nama_pelanggan(50);
            $table->DATE()->tanggal_masuk();
            $table->DEC()->jumlah();
            $table->INT()->total_biaya();
            $table->ENUM()->status();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pesanans_tabel');
    }
};
